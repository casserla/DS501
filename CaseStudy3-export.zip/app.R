
#import our libraries. 
library(shiny)
library(ggplot2) 
library(modelr)
library(tidyverse)
library(rsconnect)

rsconnect::setAccountInfo(name='04fyua-andrew-casserly', token='BCF65AF572B0CC5AB21440CCDC441F76', secret='4CfHstPNjl+NwndpPUgVSfsgO+cWpHagjWiOH+iJ')

#Import the various data sets per year. Needed to change the outline for 2022 as the design of the data changed from 2020-2022

ds15 <- read_csv("2015.csv") 
ds16 <- read_csv("2016.csv")
ds17 <- read_csv("2017.csv") 
ds18 <- read_csv("2018.csv") 
ds19 <- read_csv("2019.csv") 
ds20 <- read_csv("2020.csv") 
ds21 <- read_csv("2021.csv")
ds22 <- read_csv("2022.csv")
decisiontrees = c("Happiness Score", 
                  "Happiness Rank", 
                  "Healthy Life Expectancy Score",
                  "Social Support Score",
                  "Freedom in Life Choices Score",
                  "Generosity Score",
                  "GDP Per Capita Score",
                  "Corruption Score",
                  "Happiness Rank")

ds15 <- ds15 %>%
  transmute(
    "Country" = `Country`,
    "Rank" = `Happiness Rank`,
    "Score" = `Happiness Score`,
    "GDP" = `Economy (GDP per Capita)`,
    "Life" = `Health (Life Expectancy)`,
    "Generosity" = `Generosity`,
    "Social" = `Family`,
    "Corrupt" = `Trust (Government Corruption)`,
    "Freedom" = `Freedom`,
  )

ds15 <- ds15 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds16 <- ds16 %>%
  transmute(
    "Score" = `Happiness Score`,
    "Generosity" = `Generosity`,
    "Social" = `Family`,
    "Life" = `Health (Life Expectancy)`,
    "GDP" = `Economy (GDP per Capita)`,
    "Corrupt" = `Trust (Government Corruption)`,
    "Rank" = `Happiness Rank`,
    "Freedom" = `Freedom`,
    "Country" = `Country`,
  )

ds16 <- ds16 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds17 <- ds17 %>%
  transmute(
    "Score" = `Happiness.Score`,
    "Generosity" = `Generosity`,
    "Social" = `Family`,
    "Life" = `Health..Life.Expectancy.`,
    "GDP" = `Economy..GDP.per.Capita.`,
    "Corrupt" = `Trust..Government.Corruption.`,
    "Rank" = `Happiness.Rank`,
    "Freedom" = `Freedom`,
    "Country" = `Country`,
  )

ds17 <- ds17 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds18 <- ds18 %>%
  transmute(
    "Score" = `Score`,
    "Generosity" = `Generosity`,
    "Social" = `Social support`,
    "Life" = `Healthy life expectancy`,
    "GDP" = `GDP per capita`,
    "Corrupt" = `Perceptions of corruption`,
    "Rank" = `Overall rank`,
    "Freedom" = `Freedom to make life choices`,
    "Country" = `Country or region`,
  )

ds18 <- ds18 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds19 <- ds19 %>%
  transmute(
    "Score" = `Score`,
    "Generosity" = `Generosity`,
    "Social" = `Social support`,
    "Life" = `Healthy life expectancy`,
    "GDP" = `GDP per capita`,
    "Corrupt" = `Perceptions of corruption`,
    "Rank" = `Overall rank`,
    "Freedom" = `Freedom to make life choices`,
    "Country" = `Country or region`,
  )

ds19 <- ds19 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds20 <- ds20 %>%
  transmute(
    "Score" = `Ladder score`,
    "Generosity" = `Generosity`,
    "Social" = `Social support`,
    "Life" = `Healthy life expectancy`,
    "GDP" = `Logged GDP per capita`,
    "Corrupt" = 1-`Perceptions of corruption`,
    "Rank" = `Rank`,
    "Freedom" = `Freedom to make life choices`,
    "Country" = `Country name`,
    "Region" = `Regional indicator`
  )

ds20 <- ds20 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds21 <- ds21 %>%
  transmute(
    "Score" = `Ladder score`,
    "Generosity" = `Generosity`,
    "Social" = `Social support`,
    "Life" = `Healthy life expectancy`,
    "GDP" = `Logged GDP per capita`,
    "Corrupt" = 1-`Perceptions of corruption`,
    "Freedom" = `Freedom to make life choices`,
    "Country" = `Country name`,
    "Region" = `Regional indicator`
  )

ds21 <- ds21 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

ds22 <- ds22 %>%
  transmute(
    "Score" = `Happiness score`,
    "Generosity" = `Explained by: Generosity`,
    "Social" = `Explained by: Social support`,
    "Life" = `Explained by: Healthy life expectancy`,
    "GDP" = `Explained by: GDP per capita`,
    "Corrupt" = `Explained by: Perceptions of corruption`,
    "Rank" = `RANK`,
    "Freedom" = `Explained by: Freedom to make life choices`,
    "Country" = `Country`,
  )

ds22 <- ds22 %>%
  mutate(
    "Scoreper" = round(percent_rank(Score)*10),
    "Generosityper" = round(percent_rank(Generosity)*10),
    "Socialper" = round(percent_rank(Social)*10),
    "Lifeper" = round(percent_rank(Life)*10),
    "GDPper" = round(percent_rank(GDP)*10),
    "Corruptionper" = round(percent_rank(Corrupt)*10),
    "Freedomper" = round(percent_rank(Freedom)*10),
  )

# subset data points into train and test sets
set.seed(123)
sample <- sample(c(TRUE, FALSE), nrow(ds22), replace = T, prob = c(0.6,0.4))

# define train and test
train <- ds22[sample, ]
test <- ds22[!sample, ]

################################################################################
#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
################################################################################
# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Object 1: Title
  titlePanel("Deeper Dive into the World Happiness Report"),
  
  # Object 1: 2022 Rankings
  wellPanel(
    
    titlePanel("Showcase the 2022 Ranking"),
    fluidRow(
      
      column(3, numericInput("rank_display_count", label = "ranking", value = 5, min = 1, max = 147)),
      column(3, radioButtons("high_low_button", "order by", choices = c("Most Fortunate Countries", " Least Fortunate Countries"))),
      column(6, tableOutput("ranking_list"))
    )
    
  ),
  
  # Object 2: Statistics and Histograms
  wellPanel(
    titlePanel("Exploratory Data Analysis"),
    fluidRow(selectInput("var", 
                         label = "Choose a category to display",
                         choices = decisiontrees [decisiontrees  != "Happiness Rank"],
                         selected = "Happiness Score")),
    fluidRow(textOutput("definition")),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    fluidRow(
      column(2, helpText("Highest Scoring Countries"),tableOutput("high_scores")),
      column(2, helpText("Lowest Scoring Countries"), tableOutput("low_scores")),
      column(8,plotOutput("hist2"))
    ),
    headerPanel(""),
    headerPanel(""),
    fluidRow(
      column(6),
      column(4,verbatimTextOutput("stats")),
      column(2)
    )
    
  ),
  
  # Object 3: Slider choices
  wellPanel(
    titlePanel("Based on your preferences adjust the predictors accordingly."),
    fluidRow(
      column(9,
             helpText("Define how these factors contribute to overall country 'Happiness' which contributes to how fortunate they are (0- indicatest the lowest contribution, 10- indicates the  highest contribution)"),
             sliderInput("social",
                         label = "Strength of Social Support",
                         min = 0, max  = 10, value = 7),
             sliderInput("gdp",
                         label = "High level of GDP(Gross Domestic Product) per capita",
                         min = 0, max  = 10, value = 5),
             sliderInput("life",
                         label = "High life expectancy and lifestyle",
                         min = 0, max  = 10, value = 9),
             sliderInput("generosity",
                         label = "Generosity",
                         min = 0, max  = 10, value = 4),
             sliderInput("freedom",
                         label = "Freedom to make life choices",
                         min = 0, max  = 10, value = 6),
             sliderInput("corruption",
                         label = "Corruption level mitigation",
                         min = 0, max  = 10, value = 8)),
      column(3,helpText("The top countries best matching your selections are: "),
             tableOutput("preference_top"))
    )
    
  ),
  
  # Object 4: Single Country Report
  wellPanel(
    titlePanel("Analyze a specific country"),
    
    fluidRow(
      
      column(6,
             selectInput("country", 
                         label = "Choose a country",
                         choices = sort(ds22$Country),
                         selected = "Switzerland")
      ),
      column(6, selectInput("country_var", 
                            label = "Display a variable score over time",
                            choices = decisiontrees,
                            selected = "Freedom in Life Choices Score"))
      
    ),
    
    helpText("Full Report for 2022", style = "font-size:20px"),
    tableOutput("full_report_2022"),
    plotOutput("stat_time_series")
    
    
  ),
  
  # Object 5: Linear Regression Algorithm
  wellPanel(
    titlePanel("Regression Analysis"),
    selectInput("regression_var",
                label = "Select Variable to Regress Happiness Score Upon",
                choices = decisiontrees[2:7],
                selected = "Social Support Score"
    ),
    textOutput("model_summary"),
    plotOutput("regression_plot"),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    headerPanel(""),
    helpText("It should be noted that GDP, Life Expectancy, and Social Support in this data set appear to have a stronger relationship with the happiness score.", style = "font-size:20px"),
    headerPanel(""),
    textOutput("mlr_results1"),
    textOutput("mlr_results2")
  )
  
)      
################################################################################
#Server side 
################################################################################
# Define server logic
server <- function(input, output) {
  
  ################################################################################
  # Object 1: View the 2022 Ranking
  ranking_count <- reactive({input$rank_display_count})
  ranking_order <- reactive({input$high_low_button})
  
  output$ranking_list <- renderTable(
    if (ranking_order() == "Fortunate Countries"){
      
      ds22[1:ranking_count(),] %>%
        select(Rank, Country) %>%
        as.data.frame() %>%
        transmute("Happiness Rank" = as.integer(Rank), "Country" = Country)
      
      
    }
    else {
      ds22[(146-ranking_count() + 1):146,] %>%
        select(Rank, Country) %>%
        as.data.frame() %>%
        transmute("Happiness Rank" = as.integer(Rank), "Country" = Country) %>%
        arrange(desc(`Happiness Rank`))
    }
  )
  
  # Object 2: Statistics and HG plots
  var_choice <- reactive({
    var_name <- switch(
      input$var,
      "Happiness Score" = "Score",
      "Generosity Score" = "Generosity",
      "GDP Per Capita Score" = "GDP",
      "Happiness Rank" = "Rank",
      "Social Support Score" = "Social",
      "Healthy Life Expectancy Score" = "Life",
      "Freedom in Life Choices Score" = "Freedom",
      "Corruption Score" = "Corruption"
    )
    ds22 %>% pull(!!var_name)
  })
  #taken from the Kaggle site referenced by the WHS
  output$definition <- reactive({
    switch(
      input$var,
      "Happiness Score" = "A composite score made by the publishers of the report based on the other variables",
      "Generosity Score" = "Generosity is defined as the residual of regressing the national average of responses to the question, 'Have you donated money to a charity in past months?' on GDP capita.",
      "GDP Per Capita Score" = "GDP per capita is a measure of a country's economic output that accounts for its number of people.",
      "Social Support Score" = "Social support means having friends and other people, including family, turning to in times of need or crisis to give you a broader focus and positive self-image.",
      "Healthy Life Expectancy Score" = "Healthy Life Expectancy is the average number of years that a newborn can expect to live in 'full health' - in other words, not hampered by disabling illnesses or injuries.",
      "Freedom in Life Choices Score" = "Freedom of choice describes an individual's opportunity and autonomy to perform an action selected from at least two available options, unconstrained by external parties.",
      "Corruption Score" = "The Institutional Corrupton score is based on the Corruption Perceptions Index (CPI) is an index published annually by Transparency International since 1995, which ranks countries 'by their perceived levels of public sector corruption, as determined by expert assessments and opinion surveys.' In this shiny app a high score corresponds to low corruption"
    )
  })
  
  sorted_list <- reactive({
    ds22 %>%
      arrange(desc(var_choice())) %>%
      select(Country)
  })
  
  
  output$high_scores <- renderTable({
    sorted_list()$Country[1:10] %>%
      as.data.frame()
  })
  
  output$low_scores <- renderTable({
    sorted_list()$Country[142:146] %>%
      rev() %>%
      as.data.frame()
  })
  output$hist2 <- renderPlot({
    ggplot(ds22, aes(var_choice())) + geom_histogram(aes(y = ..count..), color = "darkblue", fill = "lightblue") + labs(title = "Distribution of Variable", x = input$var, y = "count")
  })
  
  output$stats <- renderPrint({
    summary(var_choice())
  })
  
  ##############################################################################
  #Object 3 : Sliders
  top_preferences <- reactive({
    ds22 %>%
      transmute(
        "Country" = Country,
        "composite" = input$social * as.numeric(Social) +
          input$freedom * as.numeric(Freedom) +
          input$life * as.numeric(Life) +
          input$corruption * as.numeric(Corruption) +
          input$generosity * as.numeric(Generosity) +
          input$gdp * as.numeric(GDP)
      ) %>%
      arrange(desc(composite))
  })
  
  ##############################################################################
  # Object 4: Single Country Report
  
  choice <- reactive({
    switch(input$year, 
           "2015" = ds15 %>% filter(Country == input$country),
           "2016" = ds16 %>% filter(Country == input$country),
           "2017" = ds17 %>% filter(Country == input$country),
           "2018" = ds18 %>% filter(Country == input$country),
           "2019" = ds19 %>% filter(Country == input$country),
           "2020" = ds20 %>% filter(Country == input$country),
           "2021" = ds21 %>% filter(Country == input$country),
           "2022" = ds22 %>% filter(Country == input$country)
    )
  })
  
  pltval <- reactive({switch(input$country_var, 
                             "Happiness Score" = choice()$Scoreper,
                             "Generosity Score" = choice()$Generosityper,
                             "GDP Per Capita Score" = choice()$GDPper,
                             "Happiness Rank" = choice()$Rank,
                             "Social Support Score" = choice()$Socialper,
                             "Healthy Life Expectancy Score" = choice()$Lifeper,
                             "Freedom in Life Choices Score" = choice()$Freedomper,
                             "Corruption Score" = choice()$Corruptionper)
  })
  
  output$stat_time_series <- renderPlot({
    df <- data.frame(Year = seq(2015, 2022), Score = unlist(lapply(seq(2015, 2022), function(y) {switch(as.character(y), 
                                                                                                        "2015" = ds15 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2016" = ds16 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2017" = ds17 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2018" = ds18 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2019" = ds19 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2020" = ds20 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2021" = ds21 %>% filter(Country == input$country) %>% pull(Scoreper),
                                                                                                        "2022" = ds22 %>% filter(Country == input$country) %>% pull(Scoreper)
    )})))
    ggplot(df, aes(x = Year, y = Score)) +
      geom_point(size = 5, color = "green") +
      ylim(0, 10) +
      labs(title = "Variable Score by Year", x = "Report", y = "Score")+
      geom_smooth(method = "lm", aes(group = 1)) +
      geom_smooth(se = FALSE, color = "red", aes(group = 1))
  })
  
  
  
  ################################################################################
  # Object 5: Linear Regression Algorithm
  
  regression_var_chosen <- reactive({
    switch(input$regression_var,
           "Generosity Score" = ds22$Generosity,
           "GDP Per Capita Score" = ds22$GDP,
           "Social Support Score" = ds22$Social,
           "Healthy Life Expectancy Score" = ds22$Life,
           "Freedom in Life Choices Score" = ds22$Freedom,
           "Corruption Score" = ds22$Corruption)
  })
  
  model <- reactive({
    lm(ds22$Score ~ regression_var_chosen())
  })
  
  output$model_summary <- renderPrint({
    paste(
      "Happiness Score  = ", summary(model())$coefficients[1],
      " + ", summary(model())$coefficients[2],
      " * (", input$regression_var,
      "),         ",
      "R-squared: ", summary(model())$r.squared,
      "R-squared adjusted: ", summary(model())$adj.r.squared
    )
  })
  
  output$regression_plot <- renderPlot({
    ggplot(ds22, aes(regression_var_chosen(), ds22$Score))+ geom_point()+ geom_smooth(method = "lm")+ geom_smooth(se = FALSE, color = "red") + labs(title = "Predicting Happiness Score", x = input$regression_var, y = "Happiness Score")
  })
  
  # build second model
  model_2 <- isolate(lm(ds22$Score ~ ds22$GDP + ds22$Life + ds22$Social))
  r_sq_2 <- isolate(summary(model_2))$r.squared * 100
  output$mlr_results1 <- renderPrint(
    paste(
      "Based on a multiple linear regression model, we have determined that ",r_sq_2, " percent of the variation in country happiness score can be predicted by scores for GDP per capita, Life Expectancy and Social Support."
    ))
  output$mlr_results2 <- renderPrint(
    paste(
      "Happiness Score = ",
      summary(model_2)$coefficients[1], " + ",
      summary(model_2)$coefficients[2], " * (GDP score) + ",
      summary(model_2)$coefficients[3], " * (Life expectancy score) + ",
      summary(model_2)$coefficients[4], " * (Social support score)"
    )
  )
  
}


# Run the application 
shinyApp(ui = ui, server = server)
